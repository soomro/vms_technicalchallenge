﻿/* Task output for 2 of 2
TasK detail:
Reading .net' (in Technical Challenge course)
-Deliver a set of small c# programs that uses language basics:
*Variables
*Operators
*Expressions
*Control flows
*/

// importing required namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task_DemoPrograms
{
    // this class is demonstrating control flows
    class Task_prog2
    {
        
        static void Main()
        {
            Task_prog2 a = new Task_prog2();
            // Following writeline method contain method inside, which display the result on screen
            Console.WriteLine(" Task#2: \n\n Result: " + a.SwedishNumber(3));
            
            //Read() is used to display result, till user press key to end!"
            Console.WriteLine("\n\npress Enter to exit!");
            Console.Read();
        }

        // Method returns the string against the number, passed as an argument ot method (limited to 10)
        private String SwedishNumber(int Number)
        {
            String result;

            // Switch control is used for the sake of task
            switch (Number)
            {
                case 1:
                    result = "ett";
                    break;
                case 2:
                    result = "två";
                    break;
                case 3:
                    result = "tre";
                    break;
                case 4:
                    result = "fyra";
                    break;
                case 5:
                    result = "fem";
                    break;
                case 6:
                    result = "sex";
                    break;
                case 7:
                    result = "syv";
                    break;
                case 8:
                    result = "åtta";
                    break;
                case 9:
                    result = "nio";
                    break;
                case 10:
                    result = "tio";
                    break;
                default:
                    result = "NOT Found";
                    break;
            }

            return result;

        }
    }

}
