﻿/* Task output for 1 of 2
TasK detail:
Reading .net' (in Technical Challenge course)
-Deliver a set of small c# programs that uses language basics:
*Variables
*Operators
*Expressions
*Control flow
*/

// importing required namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task_DemoPrograms
{
    // this class is demonstrating Variables, Operators, and Expressions
    class Task_prog1
    {
        float value1;
        int value2;

        static void Main1()
        {
            Task_prog1 a = new Task_prog1();

            // variable assignement part
            a.value1 = 23.3F;
            a.value2 = 33;

            // Following writeline method contain method inside, which display the result on screen
            Console.WriteLine(" Task#1: \n\n Result: " + a.multiply(a.value1, a.value2));
            
            //Read() is used to display result, till user press key to end!"
            Console.WriteLine("\n\npress Enter to exit!");
            Console.Read(); 
        }

        // Method performs multiplication operator functionality for to parameters passed
        double multiply(float a, int b)
        {
            long result = Convert.ToInt64(a * b);
            return result;
        }
    }
}
